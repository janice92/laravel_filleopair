<?php

namespace App;



class AdminUser extends User
{
    protected $table = "admin_users";
}
